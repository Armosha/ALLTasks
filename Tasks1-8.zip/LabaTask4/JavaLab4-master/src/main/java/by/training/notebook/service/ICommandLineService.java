package by.training.notebook.service;

public interface ICommandLineService {
    String getCommandDescription();
}
