import Task7.Shell;
import org.testng.annotations.Test;

@Test
public class TaskTest7 {
    public void checkSort() {
        int[] array = Shell.getSort();
    }
}
