package Task2;

public class Main {
    public static void main(String[] args) {
        Involvement inv = new Involvement();
        inv.checkInvolvement();
    }
}
