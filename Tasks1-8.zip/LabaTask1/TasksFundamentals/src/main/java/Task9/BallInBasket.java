/*package Task9;


public class BallInBasket {
}
*/