/*package Task9;

будет сделано в выходные


public class Ball {
    private BallColor color;
    private double weight;

    public Ball() {
    }

    public void ballGetColor() {
        int i = (int) (1 + Math.random() * 4);
        switch (i) {
            case 1:
                this.color = BallColor.BLUE;
                break;
            case 2:
                this.color = BallColor.GREEN;
                break;
            case 3:
                this.color = BallColor.RED;
                break;
            case 4:
                this.color = BallColor.YELLOW;
                break;
            default:
                this.color = BallColor.BLUE;
        }
    }
    public double getWeight() {
        return weight;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }
}
*/




