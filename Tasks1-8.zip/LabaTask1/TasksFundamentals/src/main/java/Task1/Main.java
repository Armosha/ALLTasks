package Task1;


public class Main {

    public static void main(String[] args) {
        Calculation calculation = new Calculation();
        calculation.cal();
        System.out.println(calculation.toString());
    }
}
