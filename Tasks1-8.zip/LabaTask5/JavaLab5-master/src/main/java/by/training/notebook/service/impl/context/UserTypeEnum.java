package by.training.notebook.service.impl.context;


public enum  UserTypeEnum {

    AUTHORIZED,
    ANONYMOUS;

}
